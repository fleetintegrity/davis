document.getElementById("year").textContent=new Date().getFullYear();
const menu=document.querySelector(".menu"),links=document.querySelector(".links");
menu.addEventListener("click",()=>{links.classList.toggle("open");menu.setAttribute("aria-expanded",links.classList.contains("open"))});
document.querySelectorAll(".links a").forEach(a=>a.addEventListener("click",()=>links.classList.remove("open")));
function submitQuote(e){e.preventDefault();const note=document.getElementById("form-note");note.textContent="Thanks — the form layout is ready. Connect it to the client's preferred inbox/form handler before publishing.";note.style.color="#087da8";return false;}