DAVIS & SON'S GLOUCESTER LTD — WEBSITE REDESIGN

Open index.html in a browser to preview.

Built as a responsive static website suitable for Cloudflare Pages, GitHub Pages,
Netlify or conventional hosting.

Before live launch:
1. Connect the quote form to the client's preferred form handler/email service.
2. Add the client's confirmed email address.
3. Replace the stylised truck illustration with approved company photography if desired.
4. Confirm all service wording, vehicle capabilities and contact details with the client.
5. Add final privacy/cookie pages if analytics or marketing cookies are introduced.

Current factual content was re-written from the company's public website rather than copied verbatim.
